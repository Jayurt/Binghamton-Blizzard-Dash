import sys, time
import wave
import pygame
from pygame.sprite import Group
from pygame.locals import *
import random
from game_classes import PlayerB
from game_classes import Snowball
from game_classes import Cone
from game_classes import Background
from game_classes import Stopsign
from game_classes import Bus
from game_classes import Cutscene
from check_all_events import check_eventB
from check_all_events import check_collisions
from check_all_events import create_enemies
from check_all_events import update_background


# The main game function
def run_game():
	pygame.init()
	pygame.mouse.set_visible(False)
	pygame.mixer.init()
	pygame.mixer.music.load('le_grand_chase.ogg')
	hit_sound = pygame.mixer.Sound('punch.wav')


	while True:
		# Set initial values
		clock = pygame.time.Clock()
		timer = 0
		font = pygame.font.SysFont('comicsans',30)
		font2 = pygame.font.SysFont('comicsans',45)
		gamestate = 0

		screen = pygame.display.set_mode((1000,500))
		screen_rect = screen.get_rect()
		pygame.display.set_caption("Binghamton Blizzard Dash")

		player = PlayerB(250,330,150, 150,screen)

		

		background = Background(0, screen, 1417, 500, 10)
	  
		snowballs = Group()
		cones = Group()
		stopsigns = Group()
		backgrounds = [background]
		
		radio = Cutscene(screen,50, 80, 800,400,10,pygame.image.load('radio/radio1.png'),pygame.image.load('radio/radio2.png'),pygame.image.load('radio/radio3.png'),pygame.image.load('radio/radio4.png'))
		radio_timer = 0
		radio_audio = pygame.mixer.Sound('radio_announcement.wav')

		intro = Cutscene(screen,120,0, 750,750,0,pygame.image.load('start_screen.png'))
	
		while True:
			clock.tick(30)
			screen.fill((120,76,57))
			intro.update()
			pygame.display.update()
			loop = True

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					sys.exit()
				elif event.type == pygame.KEYDOWN:
					if event.key == pygame.K_SPACE:
						loop = False
					elif event.key == pygame.K_q:
						sys.exit()

			if loop == False:
				break
						
		while radio.active == True:
			clock.tick(30)
			radio_timer += 1
			if radio_timer == 30:
				radio_audio.play()
		
			screen.fill((139,76,57))
			radio.update()
			pygame.display.update()

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					sys.exit()
				elif event.type == pygame.KEYDOWN:
					if event.key == pygame.K_SPACE:
						radio_timer = 420
					elif event.key == pygame.K_q:
						sys.exit()
					

			if radio_timer == 420:
				radio_audio.stop()
				break

		sleep = Cutscene(screen,0, 0, 1000,500,5,pygame.image.load('sleep/sleep1.png'),pygame.image.load('sleep/sleep2.png'),pygame.image.load('sleep/sleep3.png'),pygame.image.load('sleep/sleep4.png'),pygame.image.load('sleep/sleep5.png'),pygame.image.load('sleep/sleep6.png'),pygame.image.load('sleep/sleep7.png'),pygame.image.load('sleep/sleep8.png'))
		alarm = Cutscene(screen,0, 0, 1000, 500,5,pygame.image.load('alarm/alarm1.png'),pygame.image.load('alarm/alarm2.png'))
		wake_up = Cutscene(screen,0, 0, 1000, 500, 15,pygame.image.load('wake_up/wake1.png'),pygame.image.load('wake_up/wake2.png'),pygame.image.load('wake_up/wake3.png'),pygame.image.load('wake_up/wake4.png'))
		oh_no = Cutscene(screen,0,0,1000,500, 1,pygame.image.load('wake_up/wake4.png'))
		bedroom_timer = 0
		iteration = 0
		shout = pygame.mixer.Sound('oh_no.wav')
		phone = pygame.mixer.Sound('phone.wav')



		while True:
			clock.tick(30)
			
			bedroom_timer += 1
			
			if bedroom_timer == 160:
				shout.play()
			if bedroom_timer == 90:
				phone.play()
			if bedroom_timer == 150:
				phone.stop()


			if 0 < bedroom_timer < 90:
				sleep.update()
				phone_ring = True
			elif 90 <= bedroom_timer < 150:
		
				alarm.update()
			else:
				if iteration < 60:
					wake_up.update()
					iteration += 1
				else:
					oh_no.update()
						
			pygame.display.update()

			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					sys.exit()
				elif event.type == pygame.KEYDOWN:
					if event.key == pygame.K_q:
						sys.exit()
					elif event.key == pygame.K_SPACE:
						phone.stop()
						shout.stop()
						bedroom_timer = 290

			if bedroom_timer == 290:
				break

		

		
		pygame.mixer.music.play()
		# The main game loop
		while True:

			# If you die, the game ends
			if player.alive == False:
				gamestate = 1

			# Set framerate to 30 and count loop iterations
			clock.tick(30)
			timer += 1

			# If you survive 90 seconds, you win
			if timer == 1800: #2600 for music-synchronized ending
				gamestate = 2

			# Gamestate 0 runs the main body of the game
			if gamestate == 0:
				check_eventB(player)
				check_collisions(player,snowballs,cones,stopsigns)

				if not 1030 < timer < 1100:
					create_enemies(snowballs,screen, timer,cones,stopsigns)

				if timer == 1030:
					bus = Bus(screen)


				screen.fill((0,0,0))
				update_background(backgrounds,screen,1417,500,10)

				for backdrop in backgrounds:
					backdrop.update()
					backdrop.draw()

				# screen.fill((255,255,255))
				player.update()
				player.draw()

				if timer >= 1030:
					bus.update()
					bus.draw()

					if player.hitbox.colliderect(bus.hitbox) and player.invincible == False:
						if player.clothes > 0:
							player.clothes -= 1
							print("BUS HIT")
							player.invincible = 30
							hit_sound.play()
				
				
				for ball in snowballs:
					ball.update()
					ball.draw()

				for cone in cones:
					cone.update()
					cone.draw()

				for stopsign in stopsigns:
					stopsign.update()
					stopsign.draw()

				
				message = "Seconds Elapsed: " + str(round(timer/30))
				text = font.render(message ,1, (255,255,255))
				
				screen.blit(text,(50,30))

				pygame.display.update()


			elif gamestate == 1:
				reset = False
				screen.fill((0,0,0))
				pygame.mixer.music.stop()
				death_message = "you ran out of clothes and froze solid"

				text2 = font.render(death_message ,1, (255,255,255))
				screen.blit(text2, (300,200))

				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						sys.exit()
					if event.type == pygame.KEYDOWN:
						if event.key == K_SPACE:
							reset = True

				pygame.display.update()

			

			# Winning gamestate
			elif gamestate == 2:
				update_background(backgrounds,screen,1417,500,10)

				for backdrop in backgrounds:
					backdrop.update()
					backdrop.draw()

				player.right = False
				player.left = False
				player.x += 10
				player.update()
				player.draw()

				for ball in snowballs:
					ball.update()
					ball.draw()

				for cone in cones:
					cone.update()
					cone.draw()

				for stopsign in stopsigns:
					stopsign.update()
					stopsign.draw()

				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						sys.exit()

				pygame.display.update()

				if player.rect.left > screen_rect.right + 200:
					break

			if gamestate == 1 and reset == True:
				break

		end_timer = 0
		end_game = False
		ending = Cutscene(screen,0,0,1000,500,8,pygame.image.load('ending/ending1.png'),pygame.image.load('ending/ending2.png'))
		if player.clothes >= 11:
			end_audio = pygame.mixer.Sound('good_end.wav')
		elif player.clothes < 11:
			end_audio = pygame.mixer.Sound('neutral_end.wav')

		pygame.mixer.music.stop()

		credit1 = "Music by Kevin MacLeod"
		credit2 = "Winter Art by MachineFish"
		text3 = font2.render(credit1 ,1, (255,255,255))
		text4 = font2.render(credit2 ,1, (255,255,255))

		if gamestate == 2:
			while True:
				clock.tick(30)
				end_timer += 1

				if end_timer == 30:
					end_audio.play()

				ending.update()

				if end_timer < 100:
					screen.blit(text3, (550,460))
				elif end_timer >= 100:
					screen.blit(text4, (550,460))

				pygame.display.update()

				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						sys.exit()
					elif event.type == pygame.KEYDOWN:
						if event.key == pygame.K_SPACE:
							end_game = True
						elif event.key == pygame.K_q:
							sys.exit()

				if player.clothes >= 11: 
					if end_timer == 200:
						end_game = True

				elif player.clothes < 11:
					if end_timer == 450:
						end_game = True

				if end_game == True:
					end_audio.stop()
					break

		radio.active = True
		gamestate = 0
		player.alive = True
		player.clothes = 20
		continue


run_game()
