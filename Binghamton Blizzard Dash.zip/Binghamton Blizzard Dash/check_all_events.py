import sys
import pygame
from game_classes import Snowball
from game_classes import Cone
from game_classes import Background
from game_classes import Stopsign
import random
pygame.mixer.init()

# This file contains the primary game functions

hit_sound = pygame.mixer.Sound('punch.wav')

def check_eventB(player):
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			sys.exit()

		elif event.type == pygame.KEYDOWN:
			if event.key == pygame.K_SPACE:
				if player.jump == False:
					player.jump = True
					player.highjump = True
			elif event.key == pygame.K_LEFT:
				player.left = True
			elif event.key == pygame.K_RIGHT:
				player.right = True
			elif event.key == pygame.K_q:
				sys.exit()

		elif event.type == pygame.KEYUP:
			if event.key == pygame.K_SPACE:
				player.highjump = False
			elif event.key == pygame.K_LEFT:
				player.left = False
			elif event.key == pygame.K_RIGHT:
				player.right = False
				

def check_collisions(player,snowballs,cones,stopsigns):
	for ball in snowballs:
		if player.hitbox.colliderect(ball.hitbox) and player.invincible == False:
			if player.clothes > 0:
				player.clothes -= 1
				snowballs.remove(ball)
				hit_sound.play()
				player.invincible = 30

	for cone in cones:
		if player.hitbox.colliderect(cone.hitbox) and player.invincible == False:
			if player.clothes > 0:
				player.clothes -= 1
				hit_sound.play()
				player.invincible = 30

	for stop in stopsigns:
		if player.hitbox.colliderect(stop.hitbox) and player.invincible == False:
			if player.clothes > 0:
				player.clothes -= 1
				hit_sound.play()
				player.invincible = 30

def create_enemies(snowballs,screen,timer,cones,stopsigns):
	# Create enemies offscreen to the right and add to Group
	if len(snowballs) < 3 and timer % 15 == 0:
		y_pos = random.randint(50,300)
		vel = random.randint(25,35)

		snowby = Snowball(1200,y_pos,100,50,vel,screen,'snowball.png')
		snowballs.add(snowby)

	if len(cones) < 5 and timer % 23:
		gen = True
		for cone in cones:
			if 800 < cone.x < 1200:
				gen = False

		for stop in stopsigns:
			if 800 < stop.x < 1200:
				gen = False

		if gen == True:
			alt_chance = random.randint(1,50)
			if alt_chance == 29 and len(stopsigns) == 0:
				stoppy = Stopsign(1200,230,300,300,20,screen)
				stopsigns.add(stoppy)

			else:
				spawn_chance = random.randint(1,15)
				if spawn_chance == 2:
					coney = Cone(1200,340,200,200,20,screen)
					cones.add(coney)



	# Remove enemy objects once they leave the screen

	for snowball in snowballs:
		if snowball.rect.right < 0:
			snowballs.remove(snowball)

	for cone in cones:
		if cone.rect.right < 0:
			cones.remove(cone)

	for stop in stopsigns:
		if stop.rect.right < 0:
			stopsigns.remove(stop)


def update_background(backgrounds,screen,width,height,speed):
	larry = backgrounds[0]
	screen_rect = screen.get_rect()
	if larry.rect.right <= screen_rect.right and len(backgrounds) < 2:
		forest = Background(larry.rect.right, screen, width, height, speed)
		backgrounds.append(forest)

	elif larry.rect.right < 0:
		backgrounds.remove(larry)




