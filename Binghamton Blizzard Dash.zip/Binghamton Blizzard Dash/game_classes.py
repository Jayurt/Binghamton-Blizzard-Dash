import sys
import pygame

# All the classes used by our game are stored here

def load_image(name):
	image = pygame.image.load(name)
	return image

class Background(pygame.sprite.Sprite):
	def __init__(self, x, screen, width, height, speed):
		super(Background, self).__init__()
		self.image = pygame.image.load('forest.png')
		self.x = x 
		self.y = 0
		self.width = width
		self.height = height
		self.screen = screen
		self.animation_speed = speed
		self.timer = 0
		self.index = 0
		self.image = pygame.transform.scale(pygame.image.load('forest.png'), (self.width,self.height))
		self.rect = pygame.Rect(self.x,0,self.width,self.height)

	def update(self):
		self.x -= self.animation_speed
		self.rect = pygame.Rect(self.x,0,self.width,self.height)

	def draw(self):
		self.screen.blit(self.image, self.rect)


class PlayerB(pygame.sprite.Sprite):
	def __init__(self,x,y,width,height,screen):
		super(PlayerB, self).__init__()
		self.x = x
		self.y = y
		self.vy = 9
		self.width = width
		self.height = height
		self.screen = screen
		self.screen_rect = screen.get_rect()
		self.alive = True
		self.rect = pygame.Rect(self.x, self.y, self.width,self.height)
		self.clothes = 20
		self.invincible = 0
		self.inv_blink = 1
		self.hitbox = pygame.Rect(self.x+30, self.y+20, self.width-100,self.height)

		#Set variables to describe player's state
		#self.crouch = False
		self.jump = False
		self.highjump = True
		self.accel = 1
		self.neg = 1
		self.reverse = False

		self.left = False
		self.right = False

		#Set up player sprite and animation
		self.hat_frames = [load_image('hat/hat1.png'), load_image('hat/hat2.png'), load_image('hat/hat3.png'),load_image('hat/hat4.png'),load_image('hat/hat3.png'),load_image('hat/hat2.png')]
		self.scarf_frames = [load_image('scarf/scarf1.png'),load_image('scarf/scarf2.png'),load_image('scarf/scarf3.png'),load_image('scarf/scarf4.png'),load_image('scarf/scarf3.png'),load_image('scarf/scarf2.png')]
		self.mittens_frames = [load_image('mittens/mittens1.png'),load_image('mittens/mittens2.png'),load_image('mittens/mittens3.png'),load_image('mittens/mittens4.png'),load_image('mittens/mittens3.png'),load_image('mittens/mittens2.png')]
		self.jacket_frames = [load_image('jacket/jacket1.png'),load_image('jacket/jacket2.png'),load_image('jacket/jacket3.png'),load_image('jacket/jacket4.png'),load_image('jacket/jacket3.png'),load_image('jacket/jacket2.png')]
		self.shirt_frames = [load_image('shirt/shirt1.png'),load_image('shirt/shirt2.png'),load_image('shirt/shirt3.png'),load_image('shirt/shirt4.png'),load_image('shirt/shirt3.png'),load_image('shirt/shirt2.png')]
		self.undershirt_frames = [load_image('undershirt/undershirt1.png'),load_image('undershirt/undershirt2.png'),load_image('undershirt/undershirt3.png'),load_image('undershirt/undershirt4.png'),load_image('undershirt/undershirt3.png'),load_image('undershirt/undershirt2.png')]
		self.pants_frames = [load_image('pants/pants1.png'),load_image('pants/pants2.png'),load_image('pants/pants3.png'),load_image('pants/pants4.png'),load_image('pants/pants3.png'),load_image('pants/pants2.png')]
		self.shoes_frames = [load_image('shoes/shoes1.png'),load_image('shoes/shoes2.png'),load_image('shoes/shoes3.png'),load_image('shoes/shoes4.png'),load_image('shoes/shoes3.png'),load_image('shoes/shoes2.png')]
		self.socks_frames = [load_image('socks/socks1.png'),load_image('socks/socks2.png'),load_image('socks/socks3.png'),load_image('socks/socks4.png'),load_image('socks/socks3.png'),load_image('socks/socks2.png')]
		self.underwear_frames = [load_image('underwear/underwear1.png'),load_image('underwear/underwear2.png'),load_image('underwear/underwear3.png'),load_image('underwear/underwear4.png'),load_image('underwear/underwear3.png'),load_image('underwear/underwear2.png')]

		self.index = 0
		self.animation_speed = 3
		self.timer = 0



	def update(self):	
		# Update character sprite
		if self.timer < self.animation_speed:
			self.timer += 1
		elif self.timer == self.animation_speed:
			self.timer = 0
			self.index += 1
			if self.index >= len(self.hat_frames):
				self.index = 0


		if self.clothes >= 19:
			self.image = pygame.transform.scale(self.hat_frames[self.index], (self.width,self.height))
		elif 19 > self.clothes >= 17:
			self.image = pygame.transform.scale(self.scarf_frames[self.index], (self.width,self.height))
		elif 17 > self.clothes >= 15:
			self.image = pygame.transform.scale(self.mittens_frames[self.index], (self.width,self.height))
		elif 15 > self.clothes >= 13:
			self.image = pygame.transform.scale(self.jacket_frames[self.index], (self.width,self.height))
		elif 13 > self.clothes >= 11:
			self.image = pygame.transform.scale(self.shirt_frames[self.index], (self.width,self.height))
		elif 11 > self.clothes >= 9:
			self.image = pygame.transform.scale(self.undershirt_frames[self.index], (self.width,self.height))
		elif 9 > self.clothes >= 7:
			self.image = pygame.transform.scale(self.pants_frames[self.index], (self.width,self.height))
		elif 7 > self.clothes >= 5:
			self.image = pygame.transform.scale(self.shoes_frames[self.index], (self.width,self.height))
		elif 5 > self.clothes >= 3:
			self.image = pygame.transform.scale(self.socks_frames[self.index], (self.width,self.height))
		elif 3 > self.clothes >= 1:
			self.image = pygame.transform.scale(self.underwear_frames[self.index], (self.width,self.height))


		if self.right == True and self.rect.right + 50 < self.screen_rect.right:
			self.x += 12
		elif self.left == True and self.rect.left > 50:
			self.x -= 12


		# Determine height of jump
		if self.highjump == True:
			self.accel = 1
		elif self.highjump == False:
			self.accel = 3

		# Update player position if jumping
		if self.jump == True:
		
			self.y -= self.neg*self.vy**2

			if self.vy - self.accel < 0 and self.reverse == False:
				self.vy = 0
			elif self.vy - self.accel < 0 and self.reverse == True:
				self.vy -= self.accel
			else:
				self.vy -= self.accel

			if self.vy == 0:
				self.reverse = True
				self.neg = -self.neg

			if self.y >= 330:
				self.y = 330
				self.jump = False
				self.vy = 9
				self.neg = 1
				self.reverse = False

		# Update player rect
		self.rect = pygame.Rect(self.x, self.y, self.width,self.height)
		self.hitbox = pygame.Rect(self.x+50, self.y+10, self.width-100,self.height-50)




		# Update player's post-hit invincibility status
		if self.invincible > 0:
			self.invincible -= 1
			if self.invincible % 3 == 0:
				self.inv_blink = -self.inv_blink

		elif self.invincible == 0:
			self.inv_blink = 1

		# Check if player ran out of clothes
		if self.clothes <= 0:
			self.alive = False


	def draw(self):
		if self.alive == True and self.inv_blink == 1:
		#	pygame.draw.rect(self.screen, (0,150,0), self.hitbox)
			self.screen.blit(self.image, self.rect)

class Snowball(pygame.sprite.Sprite):
	def __init__(self,x,y,width,height,velocity,screen,*pictures):
		super(Snowball,self).__init__()
		self.x = x
		self.y = y
		self.width = width
		self.height = height
		self.screen = screen
		self.vx = velocity
		self.timer = 0
		self.index = 0
		self.animation_speed = 3
		self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
		self.hitbox = pygame.Rect(self.x+30,self.y+10,self.width-90,self.height-20)
	

		self.frames = []
		
		for picture in pictures:
			self.frames.append(pygame.image.load(picture))

		self.image = pygame.transform.scale(self.frames[self.index], (self.width,self.height))

	def update(self):
		if self.timer < self.animation_speed:
			self.timer += 1
		elif self.timer == self.animation_speed:
			self.timer = 0 
			self.index += 1
			if self.index >= len(self.frames):
				self.index = 0

		# Update snowball image
		self.image = pygame.transform.scale(self.frames[self.index], (self.width,self.height))
		
		# Update x position using velocity
		self.x -= self.vx
		self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
		self.hitbox = pygame.Rect(self.x+30,self.y+10,self.width-90,self.height-20)

	def draw(self):
		#pygame.draw.rect(self.screen, (255,0,0), self.hitbox)
		self.screen.blit(self.image,self.rect)

class Cone(pygame.sprite.Sprite):
	def __init__(self,x,y,width,height,velocity,screen):
		super(Cone,self).__init__()
		self.x = x
		self.y = y
		self.width = width
		self.height = height
		self.screen = screen
		self.vx = velocity
		self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
		self.image = pygame.transform.scale(pygame.image.load('cone.png'), (self.width,self.height))
		self.hitbox = pygame.Rect(self.x+50, self.y+70,80,300)

	def update(self):
		self.x -= self.vx
		self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
		self.hitbox = pygame.Rect(self.x+50, self.y+70,40,300)

	def draw(self):
		#pygame.draw.rect(self.screen, (255,0,0), self.hitbox)
		self.screen.blit(self.image, self.rect)


class Stopsign(pygame.sprite.Sprite):
	def __init__(self,x,y,width,height,velocity,screen):
		super(Stopsign,self).__init__()
		self.x = x
		self.y = y
		self.width = width
		self.height = height
		self.screen = screen
		self.vx = velocity
		self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
		self.picture = pygame.image.load('stop_sign.png')
		self.image = pygame.transform.scale(self.picture, (self.width,self.height))
		self.hitbox = pygame.Rect(self.x+80, self.y+70,70,300)

	def update(self):
		self.x -= self.vx
		self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
		self.hitbox = pygame.Rect(self.x+80, self.y+110,50,300)

	def draw(self):
		#pygame.draw.rect(self.screen, (255,0,0), self.hitbox)
		self.screen.blit(self.image, self.rect)

class Bus(pygame.sprite.Sprite):
	def __init__(self, screen):
		super(Bus).__init__()
		self.x = 4000
		self.y = 210
		self.vx = 60
		self.height = 500
		self.width = 500
		self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
		self.frames = [load_image('bus/bus1.png'),load_image('bus/bus2.png'),load_image('bus/bus2.png'),load_image('bus/bus3.png'),load_image('bus/bus4.png')]
		self.hitbox = pygame.Rect(self.x+10,self.y+80,self.width-60,self.height)
		self.index = 0
		self.screen = screen
		self.screen_rect = screen.get_rect()

	def update(self):
		self.x -= self.vx

		self.index += 1
		if self.index >= len(self.frames):
			self.index = 0
		self.image = pygame.transform.scale(self.frames[self.index], (self.width,self.height))

		self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
		self.hitbox = pygame.Rect(self.x+10,self.y+80,self.width-60,self.height)


	def draw(self):
		if self.rect.right >= self.screen_rect.left:
		#	pygame.draw.rect(self.screen,(255,0,0), self.hitbox)
			self.screen.blit(self.image,self.rect)

class Cutscene(pygame.sprite.Sprite):
	def __init__(self,screen,x,y,width,height,speed,*images):
		super(Cutscene,self).__init__()
		self.x = x
		self.y = y
		self.width = width
		self.height = height
		self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
		self.screen = screen
		self.active = True

		self.frames = []
		for pic in images:
			self.frames.append(pic)
		self.animation_speed = speed
		self.index = 0
		self.timer = 0
		self.image = self.frames[0]

	def update(self):
		if self.timer < self.animation_speed:
			self.timer += 1
		elif self.timer >= self.animation_speed:
			self.timer = 0
			self.index += 1
			if self.index >= len(self.frames):
				self.index = 0

		self.picture = self.frames[self.index]
		self.image = pygame.transform.scale(self.picture, (self.width,self.height))
		self.screen.blit(self.image,self.rect)












